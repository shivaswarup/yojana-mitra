import { GoogleGenAI } from '@google/genai';

// Vercel serverless function for the Yojana Mitra chatbot.
// Gemini credentials are read only on the server from GEMINI_API_KEY.
import { createServer as createViteServer } from 'vite';




// Lazy / safe initialization of Gemini AI
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('GEMINI_API_KEY not configured. AI capabilities will return fallback responses.');
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Resilient Gemini generation with model fallback on 503/429/high demand/quota
async function generateContentWithFallback(ai: GoogleGenAI, options: {
  contents: any;
  config?: any;
  primaryModel?: string;
  fallbackModels?: string[];
  retries?: number;
}) {
  const modelsToTry = [
    options.primaryModel || 'gemini-3.8-flash',
    ...(options.fallbackModels || ['gemini-3.1-flash-lite', 'gemini-flash-latest'])
  ];

  for (let i = 0; i < modelsToTry.length; i++) {
    const model = modelsToTry[i];
    const maxAttempts = i === 0 ? (options.retries ?? 1) : 0;
    
    for (let attempt = 0; attempt <= maxAttempts; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: options.contents,
          config: options.config,
        });
        return response;
      } catch (err: any) {
        const errMsg = (err?.message || String(err)).toLowerCase();
        const isTransient = 
          errMsg.includes('503') || 
          errMsg.includes('high demand') || 
          errMsg.includes('unavailable') || 
          errMsg.includes('resource_exhausted') || 
          errMsg.includes('quota') ||
          errMsg.includes('rate') ||
          errMsg.includes('429');

        if (isTransient && attempt < maxAttempts) {
          const delay = (attempt + 1) * 600 + Math.floor(Math.random() * 200);
          await new Promise((resolve) => setTimeout(resolve, delay));
          continue;
        }

        if (isTransient && i < modelsToTry.length - 1) {
          await new Promise((resolve) => setTimeout(resolve, 300));
          break;
        }

        if (!isTransient) {
          break;
        }
      }
    }
  }

  console.warn('Gemini models temporarily busy or under high demand. Serving resilient fallback.');
  return null;
}

export default async function handler(req: any, res: any) {
try {
  const { message, history, userProfile, language } = req.body;
  const ai = getGenAI();

  // Check if user specifically requested Telugu or typed in Telugu script/transliteration
  const isTeluguRequested = 
    (typeof language === 'string' && language.toLowerCase() === 'telugu') ||
    (/(\btelugu\b|తెలుగు|telugulo|telugu\s*lo)/i.test(message || '')) ||
    (/[\u0C00-\u0C7F]/.test(message || '')) ||
    (Array.isArray(history) && history.some((h: { role: string; text: string }) => 
      /(\btelugu\b|తెలుగు|telugulo|telugu\s*lo)/i.test(h.text || '') || /[\u0C00-\u0C7F]/.test(h.text || '')
    ));

  if (!ai) {
    return res.json({
      reply: isTeluguRequested
        ? `నమస్కారం! నేను మీ **యోజనా మిత్ర AI సహాయకుడిని** (Yojana Mitra AI).

లైవ్ రియల్ టైమ్ AI సమాధానాల కోసం గూగుల్ AI స్టూడియో **Settings > Secrets** ప్యానెల్‌లో \`GEMINI_API_KEY\` కాన్ఫిగర్ చేయబడి ఉండాలి.

ఆలోగా, మీరు మా హోమ్ పేజీ మరియు రికమండేషన్స్ ద్వారా మీ ప్రొఫైల్‌కు సరిపోయే వందలాది ధృవీకరించబడిన ప్రభుత్వ సంక్షేమ పథకాలు మరియు స్కాలర్‌షిప్‌లను సులభంగా పరిశీలించవచ్చు!`
        : `Hello! I am your **Yojana Mitra AI Assistant**. 

To activate live real-time AI responses with the Gemini API, please make sure your \`GEMINI_API_KEY\` is added in the **Settings > Secrets** panel in Google AI Studio.

In the meantime, you can explore hundreds of pre-verified schemes and scholarships across our database using the search and recommendation views!`
    });
  }

  const systemInstruction = `You are the official Government Scheme & Scholarship Finder Agent ("Yojana Mitra AI").
Your role is to assist Indian citizens in discovering, checking eligibility, understanding required documents, and applying for active government welfare schemes and scholarships.

CITIZEN PROFILE CONTEXT:
${userProfile ? `
- Name: ${userProfile.name || 'Citizen'}
- Age: ${userProfile.age || 'Not specified'} (${userProfile.gender || 'Not specified'})
- Marital Status: ${userProfile.maritalStatus || 'Single'}
- State/UT & District: ${userProfile.district ? `${userProfile.district}, ` : ''}${userProfile.state || 'All India'} (${userProfile.areaType || 'Urban'} sector)
- Category: ${userProfile.category || 'General'}
- Annual Family Income: ₹${userProfile.annualFamilyIncome || 'Not specified'}
- Occupation / Status: ${userProfile.occupation || userProfile.employmentStatus || 'Not specified'}
- Education: ${userProfile.highestEducation || 'Not specified'} (${userProfile.currentEducationStatus || ''})
- Student Status: ${userProfile.isStudent ? 'Yes' : 'No'}
- Farmer Status: ${userProfile.isFarmer ? 'Yes' : 'No'}
- Woman Entrepreneur / Self-Employed: ${userProfile.isWomanEntrepreneur ? 'Yes' : 'No'}
- Senior Citizen: ${userProfile.isSeniorCitizen ? 'Yes' : 'No'}
- BPL / EWS: ${userProfile.isBPLOrEWS ? 'Yes' : 'No'}
- PwD (Disability): ${userProfile.isDisability ? 'Yes' : 'No'}
` : 'No citizen profile provided (general query).'}

${isTeluguRequested ? `
CRITICAL MANDATORY DIRECTIVE - RESPOND ENTIRELY IN TELUGU (తెలుగు):
- The citizen has explicitly requested to respond in Telugu or is communicating in Telugu.
- You MUST answer the ENTIRE response in clear, natural, grammatically correct, and respectful Telugu (తెలుగు లిపి).
- DO NOT answer in English. All explanations, step-by-step guidance, criteria, and document lists must be in Telugu.
- Structure all scheme recommendations strictly in TEXT FORMAT (DO NOT USE CARDS) using this numbered format:
1.
**పథకం పేరు (Scheme Name):** [అధికారిక పథకం పేరు]
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** [అర్హత ప్రమాణాలు మరియు కావలసిన ధృవీకరణ పత్రాలు]
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** [మీ వయస్సు, విద్య, రాష్ట్రం లేదా కేటగిరీకి ఇది ఎలా సరిపోతుంది]
**గడువు తేదీ (Deadline):** [గడువు తేదీ లేదా 'Check Official Portal']
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [అధికారిక వెబ్‌సైట్ లింక్ (ఉదా. [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in))]
- Keep official English scheme titles or portal acronyms in parentheses where helpful (e.g., 'జాతీయ స్కాలర్‌షిప్ పోర్టల్ (NSP)', 'పీఎం యశస్వి (PM-YASASVI)', 'ఆధార్ డీబీటీ (Aadhaar DBT)').
- Start with a polite greeting in Telugu: "నమస్కారం! మీ ప్రొఫైల్ ఆధారంగా మీరు అర్హులైన ప్రభుత్వ పథకాలు మరియు స్కాలర్‌షిప్‌ల వివరాలు క్రింద వివరించబడ్డాయి:"
` : `
LANGUAGE CAPABILITY:
- You have full native-level fluency in English, Telugu (తెలుగు), and Hindi (हिंदी).
- Whenever a user asks 'respond in telugu', 'telugu lo cheppandi', 'reply in telugu', 'explain in telugu', 'telugulo', 'తెలుగులో చెప్పండి', or asks a question in Telugu script, you MUST immediately switch and deliver your entire response in natural, fluent Telugu script (తెలుగు లిపి).
`}

RULES & CONSTRAINTS:
1. STRICT STATE RESTRICTION (ONLY ANDHRA PRADESH & TELANGANA):
 - You EXCLUSIVELY support and concentrate on the states of **Andhra Pradesh** and **Telangana** (in addition to Pan-India Central Government schemes).
 - NEVER recommend, provide information for, or process schemes from any other states (such as Karnataka, Tamil Nadu, Maharashtra, Uttar Pradesh, etc.). If a user asks about any state other than Andhra Pradesh or Telangana, politely state: "This platform is exclusively dedicated to Andhra Pradesh and Telangana state schemes alongside Central Government schemes. I cannot recommend schemes for other states."
 - Deeply concentrate on Andhra Pradesh schemes (Jagananna Vidya Deevena, Vasathi Deevena, Videshi Vidya Deevena, YSR Cheyutha, YSR Rythu Bharosa, Dr. YSR Aarogyasri, YSR Kapu Nestham, YSR EBC Nestham, Sunna Vaddi) and Telangana schemes (Telangana ePASS Post-Matric Scholarships & Fee Reimbursement, Maha Lakshmi Scheme for Women, Overseas Vidya Nidhi, TASK Youth Training Subsidy, Rythu Bharosa, Kalyana Lakshmi / Shaadi Mubarak, Rajiv Aarogyasri).
2. STRICT PROFILE RELEVANCE: Only recommend schemes and scholarships that strictly match the citizen's profile (Age, State, Category, Income limit, Occupation/Student/Farmer/Gender). NEVER recommend schemes outside the user's profile (e.g. do not recommend farmer schemes to students, do not recommend girl-child schemes to male users, do not recommend schemes with income limits lower than the citizen's income, and do not recommend schemes restricted to other states). If the user asks about an ineligible scheme, explain clearly why they do not meet the criteria.
3. Restrict factual verification strictly to official Indian government portals and websites (e.g. .gov.in, .nic.in, myscheme.gov.in, scholarships.gov.in, pmkisan.gov.in, telanganaepass.cgg.gov.in, jnanabhumi.ap.gov.in, etc.).
4. MANDATORY TEXT FORMAT IN CHATBOX (STRICTLY NO CARDS FORMAT):
 DO NOT display schemes and scholarships in cards format. Never output card layouts, button grids, or card UI.
 You MUST output all recommended schemes and scholarships in pure text format directly in the chatbox, numbered sequentially (1., 2., 3., ...), using these EXACT terms:
 1.
 **Scheme Name:** [Official Scheme Name]
 **Requirements:** [Eligibility criteria & Required Documents]
 **Why it suits you:** [Clear reason explaining why it suits the citizen's specific age, category, student/occupation status, and income]
 **Deadline:** [Active deadline date or 'Check Official Portal']
 **Official Portal Link:** [Direct clickable official government link e.g. [National Scholarship Portal](https://scholarships.gov.in) or https://scholarships.gov.in]

 2.
 **Scheme Name:** ...
 **Requirements:** ...
 **Why it suits you:** ...
 **Deadline:** ...
 **Official Portal Link:** ...

 Make sure EVERY scheme will be represented with these terms in text format in the chatbox itself.
5. CENTRAL GOVERNMENT SCHEMES & SCHOLARSHIPS:
 When the user asks about 'central schemes', 'central government schemes', 'national schemes', 'scholarships', or any Pan-India welfare programs, you MUST identify and present all active Central Government schemes and Centrally Sponsored scholarships matching their profile:
 - For Students: PM-YASASVI Central Sector Scholarship, Central Sector Scheme of Scholarship for College and University Students, PM Vidyalaxmi Higher Education Loan Interest Subsidy, National Means-cum-Merit Scholarship Scheme (NMMSS), AICTE Pragati Scholarship for Girls, Post-Matric Scholarships for SC/ST/OBC (NSP).
 - For Farmers: PM Kisan Samman Nidhi (₹6,000/yr direct income support), PM Fasal Bima Yojana, Kisan Credit Card.
 - For General Citizens / EWS: Ayushman Bharat PM-JAY (₹5 Lakh free health hospitalization), PM Awas Yojana (PMAY), PM Surya Ghar Muft Bijli Yojana.
 - For Entrepreneurs / Self-Employed: Pradhan Mantri MUDRA Yojana, Stand-Up India, PM Vishwakarma Yojana, PM SVANidhi.
 Always format every single Central scheme using the exact numbered text format specified above.
6. MANDATORY OFFICIAL LINK REQUIREMENT: For EVERY single scheme or scholarship mentioned, you MUST provide its valid official government application URL (e.g. [National Scholarship Portal](https://scholarships.gov.in), [Telangana ePASS](https://telanganaepass.cgg.gov.in), [JnanaBhumi AP](https://jnanabhumi.ap.gov.in), [PM-KISAN](https://pmkisan.gov.in), [PM-JAY](https://pmjay.gov.in), etc.). Never omit or leave the official link blank for ANY mentioned scheme.
7. Do not invent or estimate deadlines. If a deadline is unavailable or subject to official notification, clearly state: "Check Official Portal".
8. Provide concise, clear, and reassuring guidance. Explain how to prepare paperwork (e.g. Income certificate from Tehsildar, Bonafide from college, Bank Aadhaar DBT seeding) when helpful.`;

  // Format chat messages
  const contents: any[] = [];
  if (Array.isArray(history)) {
    history.forEach((h: { role: string; text: string }) => {
      contents.push({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.text }]
      });
    });
  }

  contents.push({
    role: 'user',
    parts: [{ text: message || 'Hello, can you help me find government schemes matching my profile?' }]
  });

  const response = await generateContentWithFallback(ai, {
    primaryModel: 'gemini-3.8-flash',
    fallbackModels: ['gemini-3.1-flash-lite', 'gemini-flash-latest'],
    contents,
    config: {
      systemInstruction,
    }
  });

  if (response?.text) {
    return res.json({
      reply: response.text
    });
  }

  // Resilient fallback response tailored to user request
  const isCentralQuery = /(central|national|scholarship|యశస్వి|కేంద్ర|scholarships|yojanas|scheme)/i.test(message || '');

  if (isCentralQuery) {
    return res.json({
      reply: isTeluguRequested
        ? `మీ ప్రొఫైల్ వివరాల ఆధారంగా ధృవీకరించబడిన ప్రముఖ కేంద్ర ప్రభుత్వ పథకాలు & స్కాలర్‌షిప్‌లు క్రింద వివరించబడ్డాయి:

1.
**పథకం పేరు (Scheme Name):** పీఎం యశస్వి కేంద్రీయ స్కాలర్‌షిప్ పథకం (PM-YASASVI)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** OBC/EBC/DNT విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2.5 లక్షల లోపు. పత్రాలు: ఆధార్ కార్డు, ఆదాయ ధృవీకరణ పత్రం, కుల ధృవీకరణ పత్రం, బోనఫైడ్, ఆధార్ డీబీటీ బ్యాంకు ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** మీ విద్యా స్థాయి మరియు సామాజిక వర్గానికి కేంద్ర ప్రభుత్వం ద్వారా నేరుగా డీబీటీ స్కాలర్‌షిప్ అందిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

2.
**పథకం పేరు (Scheme Name):** కాలేజ్ & యూనివర్సిటీ విద్యార్థుల సెంట్రల్ సెక్టార్ స్కాలర్‌షిప్ (CSSS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** ఇంటర్ / 12వ తరగతి బోర్డు పరీక్షల్లో 80 శాతానికి పైగా మార్కులు, రెగ్యులర్ డిగ్రీ విద్యార్థులు, కుటుంబ ఆదాయం ₹4.5 లక్షల లోపు. పత్రాలు: మార్కుల జాబితా, కాలేజీ బోనఫైడ్, ఆదాయ పత్రం, బ్యాంకు పాస్‌బుక్.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** ఉన్నత విద్య కోసం ప్రతి సంవత్సరం ₹12,000 నుండి ₹20,000 వరకు నగదు సహాయం నేరుగా ఖాతాలో జమ చేయబడుతుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

3.
**పథకం పేరు (Scheme Name):** పీఎం విద్యాలక్ష్మి ఉన్నత విద్యా రుణ వడ్డీ రాయితీ (PM Vidyalaxmi)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** గుర్తింపు పొందిన ఉన్నత విద్యా సంస్థల్లో అడ్మిషన్, కుటుంబ ఆదాయం ₹8 లక్షల లోపు. పత్రాలు: అడ్మిషన్ లెటర్, ఫీజు రసీదు, ఆదాయ పత్రం, ఆధార్ కార్డు.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** పూచీకత్తు లేకుండా ₹7.5 లక్షల వరకు విద్యా రుణాలపై పూర్తి వడ్డీ రాయితీ లభిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [పీఎం విద్యాలక్ష్మి పోర్టల్](https://www.pmvidyalaxmi.gov.in)`
        : `Here are verified active Central Government schemes and national scholarships matching your profile:

1.
**Scheme Name:** PM YASASVI Central Sector Scheme for OBC, EBC & DNT Students
**Requirements:** OBC/EBC/DNT students enrolled in recognized schools/colleges, Family annual income under ₹2.5 Lakh. Documents: Aadhaar Card, Income Certificate, Caste Certificate, Bonafide ID, Aadhaar DBT-linked Bank Account.
**Why it suits you:** Provides merit-based financial aid directly disbursed through Aadhaar DBT to support your education expenses.
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

2.
**Scheme Name:** Central Sector Scheme of Scholarship for College and University Students
**Requirements:** Above 80th percentile in Class 12 board examinations, enrolled in regular UG/PG course, Family annual income under ₹4.5 Lakh. Documents: Class 12 Marksheet, College Bonafide Certificate, Income Certificate, Aadhaar DBT Bank Account.
**Why it suits you:** Supports undergraduate and postgraduate degree pursuits with annual scholarship disbursements (₹12,000–₹20,000/year).
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

3.
**Scheme Name:** PM Vidyalaxmi Higher Education Loan Interest Subsidy Scheme
**Requirements:** Admitted to top NIRF-ranked higher education institutions in India, Annual family income up to ₹8 Lakh. Documents: Admission Letter, Course Fee Structure, Income Certificate from Tehsildar, PAN, Aadhaar.
**Why it suits you:** Enables collateral-free education loans up to ₹7.5 Lakh with central government interest subvention.
**Deadline:** Check Official Portal
**Official Portal Link:** [PM Vidyalaxmi Portal](https://www.pmvidyalaxmi.gov.in)`
    });
  }

  const isStateQuery = /(state|రాష్ట్ర|తెలంగాణ|telangana|andhra|ఆంధ్ర|local)/i.test(message || '');

  if (isStateQuery) {
    return res.json({
      reply: isTeluguRequested
        ? `మీ ప్రొఫైల్ వివరాల ఆధారంగా ధృవీకరించబడిన ప్రముఖ రాష్ట్ర ప్రభుత్వ పథకాలు క్రింద ఇవ్వబడ్డాయి:

1.
**పథకం పేరు (Scheme Name):** తెలంగాణ ఈ-పాస్ పోస్ట్-మెట్రిక్ స్కాలర్‌షిప్ & ఫీజు రీయింబర్స్‌మెంట్ (Telangana ePASS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** తెలంగాణ వాస్తవ్యులు, ఇంటర్/డిగ్రీ/పీజీ విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2 లక్షల లోపు (SC/ST లకు ₹2.5 లక్షల లోపు). పత్రాలు: ఆదాయ ధృవీకరణ పత్రం, కుల ధృవీకరణ పత్రం, ఎస్ఎస్సీ హాల్ టికెట్, కాలేజీ బోనఫైడ్, ఆధార్ డీబీటీ బ్యాంకు ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** పూర్తి కాలేజీ ట్యూషన్ ఫీజు రీయింబర్స్‌మెంట్ (RTF) మరియు నెలవారీ వసతి భత్యం (MTF) నేరుగా అందిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ ఈ-పాస్ పోర్టల్](https://telanganaepass.cgg.gov.in)

2.
**పథకం పేరు (Scheme Name):** చీఫ్ మినిస్టర్స్ ఓవర్సీస్ స్కాలర్‌షిప్ పథకం (Overseas Vidya Nidhi)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** విదేశీ విశ్వవిద్యాలయాల్లో ఉన్నత విద్య (MS/PG) అభ్యసించే ఎస్సీ/ఎస్టీ/బీసీ విద్యార్థులు, వార్షిక ఆదాయం ₹5 లక్షల లోపు. పత్రాలు: GRE/TOEFL స్కోర్‌కార్డ్, అడ్మిషన్ ఆఫర్ లెటర్, ఆధార్, పాస్‌పోర్ట్, ఆదాయ ధృవీకరణ పత్రం.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** విదేశీ ఉన్నత విద్య కోసం గరిష్టంగా ₹20 లక్షల వరకు ఆర్థిక సహాయం గ్రాంట్‌గా మంజూరు చేస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ ఓవర్సీస్ స్కాలర్‌షిప్](https://telanganaepass.cgg.gov.in)

3.
**పథకం పేరు (Scheme Name):** తెలంగాణ యువ వికాసం స్కిల్ డెవలప్‌మెంట్ & స్వయం ఉపాధి శిక్షణ (TASK)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** తెలంగాణ యువత (వయస్సు 18-35 సం.), 10వ/12వ తరగతి లేదా గ్రాడ్యుయేషన్ పూర్తి. పత్రాలు: ఆధార్ కార్డు, విద్యార్హత పత్రాలు, స్థానికత ధృవీకరణ పత్రం.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** పరిశ్రమలకు అవసరమైన ఆధునిక సాంకేతిక నైపుణ్యాల శిక్షణ మరియు ప్లేస్‌మెంట్ కల్పిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ అకాడమీ ఫర్ స్కిల్ అండ్ నాలెడ్జ్](https://task.telangana.gov.in)`
        : `Here are verified active State Government schemes and scholarships matching your profile:

1.
**Scheme Name:** Telangana ePASS Post-Matric Scholarship & Full Fee Reimbursement (RTF & MTF)
**Requirements:** Resident of Telangana studying intermediate, degree, engineering or professional courses, Annual family income under ₹2.00 Lakh (SC/ST under ₹2.50 Lakh). Documents: Income Certificate from MeeSeva, Integrated Community Certificate, SSC Marks Card, College Bonafide, Bank Passbook (DBT-seeded).
**Why it suits you:** Reimburses 100% of your college tuition fees and provides monthly maintenance grants directly to your bank account.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana ePASS Portal](https://telanganaepass.cgg.gov.in)

2.
**Scheme Name:** Overseas Vidya Nidhi Scheme for Higher Education Abroad
**Requirements:** Students pursuing Master's / PhD degrees in recognized universities in USA, UK, Canada, Australia, Family income up to ₹5.00 Lakh. Documents: Valid Passport, Visa, Foreign University Offer Letter, GRE/IELTS/TOEFL scorecard, Income Certificate.
**Why it suits you:** Grants up to ₹20.00 Lakh direct financial assistance to support overseas tuition and living costs.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana ePASS Overseas Portal](https://telanganaepass.cgg.gov.in)

3.
**Scheme Name:** Telangana Academy for Skill and Knowledge (TASK) Youth Development Program
**Requirements:** Telangana youth aged 18–35, enrolled in diploma/degree courses or recent graduates. Documents: College ID, Aadhaar Card, Academic Marksheets.
**Why it suits you:** Provides subsidized technology and industry-grade employability skill certifications with direct campus recruitment linkage.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana Academy for Skill and Knowledge](https://task.telangana.gov.in)`
    });
  }

  // General fallback formatted in strict numbered scheme format
  return res.json({
    reply: isTeluguRequested
      ? `మీ ప్రొఫైల్ ఆధారంగా ధృవీకరించబడిన కేంద్ర మరియు రాష్ట్ర ప్రభుత్వ పథకాలు క్రింద పేర్కొన్న విధంగా ఉన్నాయి:

1.
**పథకం పేరు (Scheme Name):** పీఎం యశస్వి కేంద్రీయ స్కాలర్‌షిప్ పథకం (PM-YASASVI)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** OBC/EBC/DNT విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2.5 లక్షల లోపు. పత్రాలు: ఆధార్ కార్డు, ఆదాయ ధృవీకరణ పత్రం, కుల ధృవీకరణ పత్రం, బోనఫైడ్, ఆధార్ డీబీటీ ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** కేంద్ర ప్రభుత్వం అందించే ప్రత్యక్ష డీబీటీ విద్యా నిధి ద్వారా ఉన్నత చదువులకు సహాయం లభిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

2.
**పథకం పేరు (Scheme Name):** కాలేజ్ & యూనివర్సిటీ విద్యార్థుల సెంట్రల్ సెక్టార్ స్కాలర్‌షిప్ (CSSS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** ఇంటర్ / 12వ తరగతిలో 80 శాతానికి పైగా మార్కులు, రెగ్యులర్ డిగ్రీ విద్యార్థులు, కుటుంబ ఆదాయం ₹4.5 లక్షల లోపు. పత్రాలు: మార్కుల జాబితా, కాలేజీ బోనఫైడ్, ఆదాయ పత్రం.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** మీ మెరిట్ ఆధారంగా ప్రతి సంవత్సరం రూ. 12,000 నుండి 20,000 వరకు నేరుగా ఉపకార వేతనం అందుతుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

3.
**పథకం పేరు (Scheme Name):** తెలంగాణ ఈ-పాస్ పోస్ట్-మెట్రిక్ స్కాలర్‌షిప్ & ఫీజు రీయింబర్స్‌మెంట్ (Telangana ePASS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** పోస్ట్-మెట్రిక్ కళాశాల విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2 లక్షల లోపు. పత్రాలు: తహశీల్దార్ ఆదాయ పత్రం, కుల పత్రం, ఆధార్ డీబీటీ బ్యాంకు ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** కాలేజీ ట్యూషన్ ఫీజులను ప్రభుత్వం పూర్తిగా చెల్లించి ఉన్నత చదువులను ప్రోత్సహిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ ఈ-పాస్ పోర్టల్](https://telanganaepass.cgg.gov.in)`
      : `Here are active government schemes and scholarships matching your profile:

1.
**Scheme Name:** PM YASASVI Central Sector Scheme for OBC, EBC & DNT Students
**Requirements:** OBC/EBC/DNT students enrolled in recognized institutions, Annual family income under ₹2.5 Lakh. Documents: Aadhaar Card, Income Certificate, Caste Certificate, Bonafide ID, Aadhaar DBT-linked Bank Account.
**Why it suits you:** Provides merit-based financial aid directly disbursed through Aadhaar DBT to support your education expenses.
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

2.
**Scheme Name:** Central Sector Scheme of Scholarship for College and University Students
**Requirements:** Above 80th percentile in Class 12 board examinations, enrolled in regular UG/PG course, Family annual income under ₹4.5 Lakh. Documents: Class 12 Marksheet, College Bonafide Certificate, Income Certificate, Aadhaar DBT Bank Account.
**Why it suits you:** Supports undergraduate degree education with annual scholarship disbursements (₹12,000–₹20,000/year).
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

3.
**Scheme Name:** Telangana ePASS Post-Matric Scholarship & Full Fee Reimbursement (RTF & MTF)
**Requirements:** Resident of Telangana studying intermediate or higher education, Annual family income under ₹2.00 Lakh (SC/ST under ₹2.50 Lakh). Documents: Income Certificate from MeeSeva, Caste Certificate, SSC Marks Memo, College Bonafide, Bank Passbook.
**Why it suits you:** Reimburses 100% of college tuition fees and provides monthly maintenance stipends to eligible students.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana ePASS Portal](https://telanganaepass.cgg.gov.in)`
  });
} catch (error: any) {
  console.warn('Notice in /api/ai/chat:', error?.message || error);
  const { message, language } = req.body || {};
  const isTeluguRequested = 
    (typeof language === 'string' && language.toLowerCase() === 'telugu') ||
    (/(\btelugu\b|తెలుగు|telugulo|telugu\s*lo)/i.test(message || '')) ||
    (/[\u0C00-\u0C7F]/.test(message || ''));

  const isCentralQuery = /(central|national|scholarship|యశస్వి|కేంద్ర|scholarships|yojanas|scheme)/i.test(message || '');

  if (isCentralQuery) {
    return res.json({
      reply: isTeluguRequested
        ? `మీ ప్రొఫైల్ వివరాల ఆధారంగా ధృవీకరించబడిన ప్రముఖ కేంద్ర ప్రభుత్వ పథకాలు & స్కాలర్‌షిప్‌లు క్రింద వివరించబడ్డాయి:

1.
**పథకం పేరు (Scheme Name):** పీఎం యశస్వి కేంద్రీయ స్కాలర్‌షిప్ పథకం (PM-YASASVI)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** OBC/EBC/DNT విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2.5 లక్షల లోపు. పత్రాలు: ఆధార్ కార్డు, ఆదాయ ధృవీకరణ పత్రం, కుల ధృవీకరణ పత్రం, బోనఫైడ్, ఆధార్ డీబీటీ బ్యాంకు ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** మీ విద్యా స్థాయి మరియు సామాజిక వర్గానికి కేంద్ర ప్రభుత్వం ద్వారా నేరుగా డీబీటీ స్కాలర్‌షిప్ అందిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

2.
**పథకం పేరు (Scheme Name):** కాలేజ్ & యూనివర్సిటీ విద్యార్థుల సెంట్రల్ సెక్టార్ స్కాలర్‌షిప్ (CSSS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** ఇంటర్ / 12వ తరగతి బోర్డు పరీక్షల్లో 80 శాతానికి పైగా మార్కులు, రెగ్యులర్ డిగ్రీ విద్యార్థులు, కుటుంబ ఆదాయం ₹4.5 లక్షల లోపు. పత్రాలు: మార్కుల జాబితా, కాలేజీ బోనఫైడ్, ఆదాయ పత్రం, బ్యాంకు పాస్‌బుక్.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** ఉన్నత విద్య కోసం ప్రతి సంవత్సరం ₹12,000 నుండి ₹20,000 వరకు నగదు సహాయం నేరుగా ఖాతాలో జమ చేయబడుతుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

3.
**పథకం పేరు (Scheme Name):** పీఎం విద్యాలక్ష్మి ఉన్నత విద్యా రుణ వడ్డీ రాయితీ (PM Vidyalaxmi)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** గుర్తింపు పొందిన ఉన్నత విద్యా సంస్థల్లో అడ్మిషన్, కుటుంబ ఆదాయం ₹8 లక్షల లోపు. పత్రాలు: అడ్మిషన్ లెటర్, ఫీజు రసీదు, ఆదాయ పత్రం, ఆధార్ కార్డు.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** పూచీకత్తు లేకుండా ₹7.5 లక్షల వరకు విద్యా రుణాలపై పూర్తి వడ్డీ రాయితీ లభిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [పీఎం విద్యాలక్ష్మి పోర్టల్](https://www.pmvidyalaxmi.gov.in)`
        : `Here are verified active Central Government schemes and national scholarships matching your profile:

1.
**Scheme Name:** PM YASASVI Central Sector Scheme for OBC, EBC & DNT Students
**Requirements:** OBC/EBC/DNT students enrolled in recognized schools/colleges, Family annual income under ₹2.5 Lakh. Documents: Aadhaar Card, Income Certificate, Caste Certificate, Bonafide ID, Aadhaar DBT-linked Bank Account.
**Why it suits you:** Provides merit-based financial aid directly disbursed through Aadhaar DBT to support your education expenses.
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

2.
**Scheme Name:** Central Sector Scheme of Scholarship for College and University Students
**Requirements:** Above 80th percentile in Class 12 board examinations, enrolled in regular UG/PG course, Family annual income under ₹4.5 Lakh. Documents: Class 12 Marksheet, College Bonafide Certificate, Income Certificate, Aadhaar DBT Bank Account.
**Why it suits you:** Supports undergraduate and postgraduate degree pursuits with annual scholarship disbursements (₹12,000–₹20,000/year).
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

3.
**Scheme Name:** PM Vidyalaxmi Higher Education Loan Interest Subsidy Scheme
**Requirements:** Admitted to top NIRF-ranked higher education institutions in India, Annual family income up to ₹8 Lakh. Documents: Admission Letter, Course Fee Structure, Income Certificate from Tehsildar, PAN, Aadhaar.
**Why it suits you:** Enables collateral-free education loans up to ₹7.5 Lakh with central government interest subvention.
**Deadline:** Check Official Portal
**Official Portal Link:** [PM Vidyalaxmi Portal](https://www.pmvidyalaxmi.gov.in)`
    });
  }

  const isStateQuery = /(state|రాష్ట్ర|తెలంగాణ|telangana|andhra|ఆంధ్ర|local)/i.test(message || '');

  if (isStateQuery) {
    return res.json({
      reply: isTeluguRequested
        ? `మీ ప్రొఫైల్ వివరాల ఆధారంగా ధృవీకరించబడిన ప్రముఖ రాష్ట్ర ప్రభుత్వ పథకాలు క్రింద ఇవ్వబడ్డాయి:

1.
**పథకం పేరు (Scheme Name):** తెలంగాణ ఈ-పాస్ పోస్ట్-మెట్రిక్ స్కాలర్‌షిప్ & ఫీజు రీయింబర్స్‌మెంట్ (Telangana ePASS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** తెలంగాణ వాస్తవ్యులు, ఇంటర్/డిగ్రీ/పీజీ విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2 లక్షల లోపు (SC/ST లకు ₹2.5 లక్షల లోపు). పత్రాలు: ఆదాయ ధృవీకరణ పత్రం, కుల ధృవీకరణ పత్రం, ఎస్ఎస్సీ హాల్ టికెట్, కాలేజీ బోనఫైడ్, ఆధార్ డీబీటీ బ్యాంకు ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** పూర్తి కాలేజీ ట్యూషన్ ఫీజు రీయింబర్స్‌మెంట్ (RTF) మరియు నెలవారీ వసతి భత్యం (MTF) నేరుగా అందిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ ఈ-పాస్ పోర్టల్](https://telanganaepass.cgg.gov.in)

2.
**పథకం పేరు (Scheme Name):** చీఫ్ మినిస్టర్స్ ఓవర్సీస్ స్కాలర్‌షిప్ పథకం (Overseas Vidya Nidhi)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** విదేశీ విశ్వవిద్యాలయాల్లో ఉన్నత విద్య (MS/PG) అభ్యసించే ఎస్సీ/ఎస్టీ/బీసీ విద్యార్థులు, వార్షిక ఆదాయం ₹5 లక్షల లోపు. పత్రాలు: GRE/TOEFL స్కోర్‌కార్డ్, అడ్మిషన్ ఆఫర్ లెటర్, ఆధార్, పాస్‌పోర్ట్, ఆదాయ ధృవీకరణ పత్రం.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** విదేశీ ఉన్నత విద్య కోసం గరిష్టంగా ₹20 లక్షల వరకు ఆర్థిక సహాయం గ్రాంట్‌గా మంజూరు చేస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ ఓవర్సీస్ స్కాలర్‌షిప్](https://telanganaepass.cgg.gov.in)

3.
**పథకం పేరు (Scheme Name):** తెలంగాణ యువ వికాసం స్కిల్ డెవలప్‌మెంట్ & స్వయం ఉపాధి శిక్షణ (TASK)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** తెలంగాణ యువత (వయస్సు 18-35 సం.), 10వ/12వ తరగతి లేదా గ్రాడ్యుయేషన్ పూర్తి. పత్రాలు: ఆధార్ కార్డు, విద్యార్హత పత్రాలు, స్థానికత ధృవీకరణ పత్రం.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** పరిశ్రమలకు అవసరమైన ఆధునిక సాంకేతిక నైపుణ్యాల శిక్షణ మరియు ప్లేస్‌మెంట్ కల్పిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ అకాడమీ ఫర్ స్కిల్ అండ్ నాలెడ్జ్](https://task.telangana.gov.in)`
        : `Here are verified active State Government schemes and scholarships matching your profile:

1.
**Scheme Name:** Telangana ePASS Post-Matric Scholarship & Full Fee Reimbursement (RTF & MTF)
**Requirements:** Resident of Telangana studying intermediate, degree, engineering or professional courses, Annual family income under ₹2.00 Lakh (SC/ST under ₹2.50 Lakh). Documents: Income Certificate from MeeSeva, Integrated Community Certificate, SSC Marks Card, College Bonafide, Bank Passbook (DBT-seeded).
**Why it suits you:** Reimburses 100% of your college tuition fees and provides monthly maintenance grants directly to your bank account.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana ePASS Portal](https://telanganaepass.cgg.gov.in)

2.
**Scheme Name:** Overseas Vidya Nidhi Scheme for Higher Education Abroad
**Requirements:** Students pursuing Master's / PhD degrees in recognized universities in USA, UK, Canada, Australia, Family income up to ₹5.00 Lakh. Documents: Valid Passport, Visa, Foreign University Offer Letter, GRE/IELTS/TOEFL scorecard, Income Certificate.
**Why it suits you:** Grants up to ₹20.00 Lakh direct financial assistance to support overseas tuition and living costs.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana ePASS Overseas Portal](https://telanganaepass.cgg.gov.in)

3.
**Scheme Name:** Telangana Academy for Skill and Knowledge (TASK) Youth Development Program
**Requirements:** Telangana youth aged 18–35, enrolled in diploma/degree courses or recent graduates. Documents: College ID, Aadhaar Card, Academic Marksheets.
**Why it suits you:** Provides subsidized technology and industry-grade employability skill certifications with direct campus recruitment linkage.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana Academy for Skill and Knowledge](https://task.telangana.gov.in)`
    });
  }

  // Return friendly resilient fallback formatted in strict numbered scheme format
  res.json({
    reply: isTeluguRequested
      ? `మీ ప్రొఫైల్ ఆధారంగా ధృవీకరించబడిన ప్రముఖ కేంద్ర మరియు రాష్ట్ర ప్రభుత్వ పథకాలు క్రింద పేర్కొన్న విధంగా ఉన్నాయి:

1.
**పథకం పేరు (Scheme Name):** పీఎం యశస్వి కేంద్రీయ స్కాలర్‌షిప్ పథకం (PM-YASASVI)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** OBC/EBC/DNT విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2.5 లక్షల లోపు. పత్రాలు: ఆధార్ కార్డు, ఆదాయ ధృవీకరణ పత్రం, కుల ధృవీకరణ పత్రం, బోనఫైడ్, ఆధార్ డీబీటీ ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** కేంద్ర ప్రభుత్వం అందించే ప్రత్యక్ష డీబీటీ విద్యా నిధి ద్వారా ఉన్నత చదువులకు సహాయం లభిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

2.
**పథకం పేరు (Scheme Name):** కాలేజ్ & యూనివర్సిటీ విద్యార్థుల సెంట్రల్ సెక్టార్ స్కాలర్‌షిప్ (CSSS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** ఇంటర్ / 12వ తరగతిలో 80 శాతానికి పైగా మార్కులు, రెగ్యులర్ డిగ్రీ విద్యార్థులు, కుటుంబ ఆదాయం ₹4.5 లక్షల లోపు. పత్రాలు: మార్కుల జాబితా, కాలేజీ బోనఫైడ్, ఆదాయ పత్రం.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** మీ మెరిట్ ఆధారంగా ప్రతి సంవత్సరం రూ. 12,000 నుండి 20,000 వరకు నేరుగా ఉపకార వేతనం అందుతుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [నేషనల్ స్కాలర్‌షిప్ పోర్టల్](https://scholarships.gov.in)

3.
**పథకం పేరు (Scheme Name):** తెలంగాణ ఈ-పాస్ పోస్ట్-మెట్రిక్ స్కాలర్‌షిప్ & ఫీజు రీయింబర్స్‌మెంట్ (Telangana ePASS)
**అర్హతలు & అవసరమైన పత్రాలు (Requirements):** పోస్ట్-మెట్రిక్ కళాశాల విద్యార్థులు, వార్షిక కుటుంబ ఆదాయం ₹2 లక్షల లోపు. పత్రాలు: తహశీల్దార్ ఆదాయ పత్రం, కుల పత్రం, ఆధార్ డీబీటీ బ్యాంకు ఖాతా.
**మీకు ఎందుకు సరిపోతుంది (Why it suits you):** కాలేజీ ట్యూషన్ ఫీజులను ప్రభుత్వం పూర్తిగా చెల్లించి ఉన్నత చదువులను ప్రోత్సహిస్తుంది.
**గడువు తేదీ (Deadline):** Check Official Portal
**అధికారిక పోర్టల్ లింక్ (Official Portal Link):** [తెలంగాణ ఈ-పాస్ పోర్టల్](https://telanganaepass.cgg.gov.in)`
      : `Here are active government schemes and scholarships matching your profile:

1.
**Scheme Name:** PM YASASVI Central Sector Scheme for OBC, EBC & DNT Students
**Requirements:** OBC/EBC/DNT students enrolled in recognized institutions, Annual family income under ₹2.5 Lakh. Documents: Aadhaar Card, Income Certificate, Caste Certificate, Bonafide ID, Aadhaar DBT-linked Bank Account.
**Why it suits you:** Provides merit-based financial aid directly disbursed through Aadhaar DBT to support your education expenses.
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

2.
**Scheme Name:** Central Sector Scheme of Scholarship for College and University Students
**Requirements:** Above 80th percentile in Class 12 board examinations, enrolled in regular UG/PG course, Family annual income under ₹4.5 Lakh. Documents: Class 12 Marksheet, College Bonafide Certificate, Income Certificate, Aadhaar DBT Bank Account.
**Why it suits you:** Supports undergraduate degree education with annual scholarship disbursements (₹12,000–₹20,000/year).
**Deadline:** Check Official Portal
**Official Portal Link:** [National Scholarship Portal](https://scholarships.gov.in)

3.
**Scheme Name:** Telangana ePASS Post-Matric Scholarship & Full Fee Reimbursement (RTF & MTF)
**Requirements:** Resident of Telangana studying intermediate or higher education, Annual family income under ₹2.00 Lakh (SC/ST under ₹2.50 Lakh). Documents: Income Certificate from MeeSeva, Caste Certificate, SSC Marks Memo, College Bonafide, Bank Passbook.
**Why it suits you:** Reimburses 100% of college tuition fees and provides monthly maintenance stipends to eligible students.
**Deadline:** Check Official Portal
**Official Portal Link:** [Telangana ePASS Portal](https://telanganaepass.cgg.gov.in)`
  });
}
}
}
